#!/usr/bin/bash

exec /blue/zoo4926/share/conda/envs/vit/bin/python3 -m ipykernel "$@"
