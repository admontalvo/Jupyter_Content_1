# American Sign Language Dataset

This dataset is from [https://www.kaggle.com/ayuraj/asl-dataset](https://www.kaggle.com/ayuraj/asl-dataset).

Downloaded 2022-02-28.
