# Metadata for the CO-OPS__8729108__wl.csv data file.

This file was downloaded from the [NOAA Tides & Currents site](https://tidesandcurrents.noaa.gov/waterlevels.html?id=8729108&units=standard&bdate=20181009&edate=20181012&timezone=GMT&datum=MLLW&interval=6&action=) on 10/11/18.

It is the water level observations (unconfirmed preliminary data) from the Panama City, FL station during Hurricane Michael.

|Column name | Description|
|------------|------------|
| Date Time | Date and time of observation
|Water Level | Observed water level
| Sigma | ??
|O |??
|F |??
|R |??
| L|??
|Quality| p=preliminary 

So...I don't really know what most of the columns are...but the important ones for this are the first two--Date Time and Water Level.
