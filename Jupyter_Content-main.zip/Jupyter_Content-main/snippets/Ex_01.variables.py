# Integers 
a=10
b=6
print(f"a is {a} \nb is {b}\n")

# Floats
x=7.5
y=9.
print(f"x is {x} \ny is {y}\n")

# Strings
name='matt'
number='three'
print(f"Your name is {name} and you have {number} fingers.\n")

# Add two int variables
c=a+b
print(f"{a} + {b} = {c}\n")

# Add two float variables
z=x+y
print(f"{x} + {y} = {z}\n")

# Add an int and a float
j=a+y
print(f"{a} + {y} = {j} \nAnd j is type: {type(j)}\n")

# Divide a int by a float
k=a/y
print(f"{a} / {y} = {k} \nAnd k is type: {type(k)}.")
print("Note that his is different than Python 2 behavior. In Python 2, you would get 1.\n")
